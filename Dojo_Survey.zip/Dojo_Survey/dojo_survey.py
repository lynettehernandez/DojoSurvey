from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def submit_page(): 
    return render_template("submit_page.html")

@app.route('/result', methods=['POST'])
def results_page():
    their_name=request.form['your_name']
    their_location=request.form['your_location']
    their_fav_lang=request.form['your_fav_lang']
    their_comment=request.form['your_comment']
    return render_template("results_page.html", name_entered=their_name, location_entered=their_location, language_entered=their_fav_lang, comment_entered=their_comment)

if __name__ == "__main__": 
    app.run(debug=True)